package com.exam.theta2k15;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Seetha on 11-03-2015.
 */
public class Eletes extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eletes);
    }
}
