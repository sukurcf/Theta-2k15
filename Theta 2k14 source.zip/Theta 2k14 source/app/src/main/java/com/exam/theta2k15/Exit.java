package com.exam.theta2k15;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import com.exam.theta2k15.R;

public class Exit extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exit);
	
		Button b1=(Button) findViewById(R.id.exit_1);
		Button b2=(Button) findViewById(R.id.exit_2);
		
	
	}
	
	
}
