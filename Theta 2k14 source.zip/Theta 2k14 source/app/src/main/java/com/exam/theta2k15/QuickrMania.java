package com.exam.theta2k15;

import android.app.Activity;
import android.os.Bundle;
import com.exam.theta2k15.R;

public class QuickrMania extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

	setContentView(R.layout.quickrmania);
	}

}
