package com.exam.theta2k15;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Gabbar Reddy Sukumar on 3/12/2015.
 */
public class Informaticaconus extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informaticaconus);
    }
}
